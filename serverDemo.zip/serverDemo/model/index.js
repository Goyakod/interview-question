
var mongoose = require('mongoose');
var path = require('path');
var config   = require('../config');
var fs = require('fs')
mongoose.Promise = global.Promise;

mongoose.connect(config.db , function (err) {
    if (err) {
        console.log('connect to %s error: ' , config.db , err.message);
        connected = false;
    }else {
        connected = true;
        var db    = mongoose.connection;
        db.on('error' , function () {
            console.log('connection error');
        });
        db.once('open' , function callback() {
            console.log('connect to %s succeed!' , config.db);
        });
    }
});

exports.getModel = function (name) {

    var file = path.join(__dirname, name + '.js');

    if (fs.existsSync(file)) {
        var schema = require(file).schema;
        if (schema) {
            return mongoose.model(name, schema);
        }
        else {
            console.log('NO Schema:' + name);
        }
    }

    return undefined;
};
