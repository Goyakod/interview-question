
var mongoose = require('mongoose');

//便签模型
exports.schema = new mongoose.Schema({
    content   : String ,    //内容
    completed : Boolean,
    createAt  : Date
});
