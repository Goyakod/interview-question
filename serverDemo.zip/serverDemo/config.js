var path = require('path');

var mongo = {
    "hostname": "127.0.0.1",
    "port": 27017,
    "username": "node",
    "password": "node_password",
    "name": "",
    "db": "zxmanager"
}

var generate_mongo_url = function (obj) {
    obj.hostname = (obj.hostname || 'localhost');
    obj.port = (obj.port || 27017);
    obj.db = (obj.db || 'test');
    if (obj.username && obj.password) {
        return "mongodb://" + obj.username + ":" + obj.password + "@" + obj.hostname + ":" + obj.port + "/" + obj.db;
    } else {
        return "mongodb://" + obj.hostname + ":" + obj.port + "/" + obj.db;
    }
};

exports.db = generate_mongo_url(mongo);
