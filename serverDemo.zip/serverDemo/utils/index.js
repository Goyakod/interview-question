var Result   = {};

/**
 * @param code 错误码
 * @param msg 错误信息
 * @param res
 * @returns {*}
 */
Result.failed = function (res, msg) {
    var json = {
        code: 400 ,
        data: {} ,
        msg : msg
    };
    console.log(JSON.stringify(json));
    return res.json(json);
};

/**
 * 操作成功返回，json数据
 * @param data
 * @param res
 * @returns {*}
 */
Result.success = function (res, data) {
    var json = {
        code: 200 ,
        data: data ,
        msg : '操作成功'
    };
    console.log(JSON.stringify(json));
    return res.json(json);
};

module.exports = Result;
