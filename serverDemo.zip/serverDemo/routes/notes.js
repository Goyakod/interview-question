var express = require('express');
var router = express.Router();
var NoteModel = require('../model').getModel('notes');
var Result = require('../utils');

router.get('/list', function(req, res, next) {

  NoteModel.find({completed:false}).sort({'_id':-1}).exec(function (err, notes) {
    if (err) {
      Result.failed(res,'获取列表失败');
    }else {
      Result.success(res, notes);
    }
  });

});

router.post('/add', function(req, res, next) {
  if (!req.body.content) {
    return  Result.failed(res,'内容不能为空');
  }

  var instance = new NoteModel({
    content: req.body.content ,
    completed: false
  });
  instance.save(function (err,save_res) {
    if (err) {
      Result.failed(res,'添加任务失败');
    }else {
      Result.success(res, save_res);
    }
  });
});

router.post('/delete', function(req, res, next) {
  if (!req.body.id) {
    return Result.failed(res,'id不能为空');
  }
  NoteModel.remove({_id:req.body.id},function (err,del_res) {
    if (err) {
      Result.failed(res,'删除任务失败');
    }else {
      Result.success(res, del_res);
    }
  });
});

router.post('/update', function(req, res, next) {
  if (!req.body.id) {
    return Result.failed(res,'id不能为空');
  }
  NoteModel.update({_id:req.body.id},{
    completed: true },function (err,update_res) {
      if (err) {
        Result.failed(res,'完成任务失败');
      }else {
        Result.success(res, update_res);
      }
  });
});

module.exports = router;
