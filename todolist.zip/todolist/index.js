import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux'
import createSagaMiddleware from 'redux-saga'
import App from './components/App';
import todoApp from './reducers';
import mySaga from './sagas'

const sagaMiddleware = createSagaMiddleware(mySaga)

const store = createStore(
  todoApp,
  applyMiddleware(sagaMiddleware),
)
sagaMiddleware.run(mySaga)

render(
	<Provider store={store}>
		<App />
	</Provider >,
	document.getElementById('root')
);
