import {
	GET_LIST,
	GET_LIST_FAIL,
	GET_LIST_SUCCESS,
	ADD_NOTE,
	ADD_NOTE_FAIL,
	ADD_NOTE_SUCCESS,
	COMPLETE_NOTE,
	COMPLETE_NOTE_FAIL,
	COMPLETE_NOTE_SUCCESS
} from '../actions'


export default function(state={
	todos: [],
	loading: false,
	error: false,
	data: {},
	msg: ''
},action){
	switch(action.type) {

		case GET_LIST:
		case ADD_NOTE:
		case COMPLETE_NOTE:
			return Object.assign({}, state, {loading: true})

		case GET_LIST_FAIL:
		case ADD_NOTE_FAIL:
		case COMPLETE_NOTE_FAIL:
			return Object.assign({}, state, { loading: false, error: true, msg: action.message})

		case GET_LIST_SUCCESS:
			return Object.assign({}, state, { loading: false, todos: action.data })
		case ADD_NOTE_SUCCESS:
		case COMPLETE_NOTE_SUCCESS:
			return Object.assign({}, state, { loading: false, data: action.data })

		default:
			return state
	}
}
