import notes from './notes';
import { combineReducers } from 'redux';

const todoApp = combineReducers({
	notes
});

export default todoApp;
