import querystring from 'querystring'
import fetch from 'isomorphic-fetch'

const API = 'http://localhost:3000';

function callApi ( cmd, method='GET', data={}, header={}, fileList=false ) {

	method = method.toUpperCase()
	let option = {
		method,
		headers: {
			'Content-Type': 'application/json',
		},
	}

	if(method == 'GET' || method == 'PATCH' || method == 'DELETE'){
    data = querystring.stringify(data)
    if (data) {
      cmd += "?" + data
    }
	}else{
		option.body = JSON.stringify(data)
	}

	let url =`${API}${cmd}`
  console.log('callApi--->',url,option);

	return fetch(url,option)
	.then(res=>{
    if (res.status == 200) {
      return res.json()
    }else {
      return res.statusText;
    }
  })
  .catch(err=>{
    return err;
  })
}

export const fetchNoteList = () =>  callApi('/notes/list')
export const fetchCompleteNote = (id) =>  callApi('/notes/update','POST',id)
export const fetchAddNote = (content) =>  callApi('/notes/add','POST',content)
