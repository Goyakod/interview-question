import { fork, take, call, put, all, select, takeEvery } from 'redux-saga/effects'
import * as actions from '../actions'
import { fetchNoteList, fetchCompleteNote, fetchAddNote } from '../api'
import 'babel-polyfill'

function* getNotesList(action) {
   try {
      const lists = yield call(fetchNoteList);
      yield put({type: actions.GET_LIST_SUCCESS, data: lists.data});
   } catch (e) {
      yield put({type: actions.GET_LIST_FAIL, message: e.message});
   }
}

function* completeNote(action) {
   try {
      const completeResult = yield call(fetchCompleteNote,{id:action.id});
      yield put({type: actions.COMPLETE_NOTE_SUCCESS, data: completeResult.data});
   } catch (e) {
      yield put({type: actions.COMPLETE_NOTE_FAIL, message: e.message});
   }
}

function* addNote(action) {
   try {
      const addResult = yield call(fetchAddNote,{content:action.content});
      yield put({type: actions.ADD_NOTE_SUCCESS, data: addResult.data});
   } catch (e) {
      yield put({type: actions.ADD_NOTE_FAIL, message: e.message});
   }
}

export function* watchGetList() {
  yield takeEvery(actions.GET_LIST, getNotesList)
}

export function* watchAddNote() {
  yield takeEvery(actions.ADD_NOTE, addNote)
}

export function* watchCompleteNote() {
  yield takeEvery(actions.COMPLETE_NOTE, completeNote)
}


export default function* () {
  yield all([
    fork(watchGetList),
    fork(watchAddNote),
    fork(watchCompleteNote)
  ])
}
