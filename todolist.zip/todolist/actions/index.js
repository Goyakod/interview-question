
export const GET_LIST = 'GET_LIST'
export const GET_LIST_FAIL = 'GET_LIST_FAIL'
export const GET_LIST_SUCCESS = 'GET_LIST_SUCCESS'

export const ADD_NOTE = 'ADD_NOTE'
export const ADD_NOTE_FAIL = 'ADD_NOTE_FAIL'
export const ADD_NOTE_SUCCESS = 'ADD_NOTE_SUCCESS'

export const COMPLETE_NOTE = 'COMPLETE_NOTE'
export const COMPLETE_NOTE_FAIL = 'COMPLETE_NOTE'
export const COMPLETE_NOTE_SUCCESS = 'COMPLETE_NOTE_SUCCESS'


export function getNotesList(){
	return { type: GET_LIST }
}

export function addNewNote(content){
	return { type: ADD_NOTE, content }
}
export function completeNote(id){
	return { type: COMPLETE_NOTE, id }
}
