import React, {Component, PropTypes} from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { routerActions } from 'react-router-redux'
import './index.css'
import 'babel-polyfill'
import { getNotesList, addNewNote, completeNote } from '../actions'
// import io from 'socket.io-client'
// const socket = io('http://localhost:3000')

class App extends Component {

	constructor(props) {
    super(props)
    this.state = {
			EditingContent: '',
			todos: []
    }
  }

	async componentDidMount() {
		// socket.io
		// socket.on('notes list',(msg)=>{
		// 	this.setState({todos: msg})
		// 	console.log('notes list==>',msg);
		// });
		this.props.getNotesList();

  }

	addItem(){
		// socket.emit('add note', this.state.EditingContent);

		if (this.state.EditingContent) {
			this.props.addNewNote(this.state.EditingContent);
		}
	}

	deleteItem(itemId){
		// socket.emit('delete note', itemId);


		if (itemId) {
			this.props.completeNote(itemId);
		}
	}

	render(){
		const todos = this.props.notes.todos || [];
		console.log('this.props.notes--->',this.props.notes);
		// const todos = this.state.todos || [];
		return(
			<div className="todo-box">
				<div className="todo-innerBox">
					全部任务
					<ul className="list-group">
					{
						todos.map(todo =>
							<li key={todo._id} className="todo-list_li" >
								<input type="checkbox" className="pull-left" onClick={()=>{this.deleteItem(todo._id)}} />
								{todo.content}
							</li>
						)
					}
					</ul>
					<div>
						<input placeholder="点此添加您的待办" className="todo-input" onChange={(e)=>{this.setState({EditingContent:e.target.value})}}/>
						<button type="submit" className="todo-btn" onClick={()=>this.addItem()}> 添加 </button>
					</div>
				</div>
			</div>
		)
	}
}


function mapStateToProps(state) {
  return {
		notes: state.notes
	}
}

export default connect(mapStateToProps, { getNotesList, addNewNote, completeNote })(App);
